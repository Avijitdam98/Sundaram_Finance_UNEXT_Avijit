package com.example.phour;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootPractApplication {
    public static void main(String[] args) {
        SpringApplication.run(SpringBootPractApplication.class, args);
        System.out.println("Application is running...");
    }
}