package com.example.phour.dto;

public class BudgetDTO {
    private int userId;
    private String category;
    private double amount;
    private String month;

    public BudgetDTO() {}

    public BudgetDTO(int userId, String category, double amount, String month) {
        this.userId = userId;
        this.category = category;
        this.amount = amount;
        this.month = month;
    }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }

    public String getMonth() { return month; }
    public void setMonth(String month) { this.month = month; }
}
