package com.example.phour.service;

import org.springframework.stereotype.Service;
import com.example.phour.model.Budget;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class BudgetService {
    private final List<Budget> budgetList = new ArrayList<>();

    public BudgetService() {
        budgetList.add(new Budget(101, 201, "Home", 5000, "April"));
        budgetList.add(new Budget(102, 202, "Health", 6000, "May"));
        budgetList.add(new Budget(103, 203, "Sport", 4000, "June"));
        budgetList.add(new Budget(104, 204, "Entertainment", 5000, "April"));
        budgetList.add(new Budget(105, 205, "Travel", 5000, "Aug"));
    }

    public List<Budget> getAllBudgets() {
        return budgetList;
    }

    public List<Budget> getBudgetsByUserId(int userId) {
        return budgetList.stream()
                .filter(budget -> budget.getUserId() == userId)
                .collect(Collectors.toList());
    }

    public Budget getBudgetById(int id) {
        return budgetList.stream()
                .filter(budget -> budget.getId() == id)
                .findFirst()
                .orElse(null);
    }

    public Budget addBudget(Budget budget) {
        budgetList.add(budget);
        return budget;
    }

    public boolean deleteBudget(int id) {
        return budgetList.removeIf(budget -> budget.getId() == id);
    }
}