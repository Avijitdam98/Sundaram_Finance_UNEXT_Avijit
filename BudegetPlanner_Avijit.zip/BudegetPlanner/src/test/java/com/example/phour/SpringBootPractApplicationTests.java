package com.example.phour;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootPractApplicationTests {

	@Test
	void contextLoads() {
	}

}
